# CobbleMarket 持卡状态示例 —— 每 tick 入口
# 通道：实体 tag cobblemarket_purple_card / cobblemarket_black_card
#       计分板 cm_purple / cm_black = 1/0（本示例用 tag，计分板写法见 README）
#
# 计时器 objective `carddemo` 由 data/cardstatus/function/load.mcfunction 在加载时创建

# ── 场景 1：没卡的玩家持续掉血（每 40 tick ≈ 2 秒掉 1 点）──
scoreboard players add #carddemo_tick carddemo 1
execute if score #carddemo_tick carddemo matches 40.. run function cardstatus:hurt
execute if score #carddemo_tick carddemo matches 40.. run scoreboard players set #carddemo_tick carddemo 0

# ── 场景 2：没卡不能进入某个区域（进区即被弹出）──
# ⚠ 每 tick 检查一次；玩家很多 / 区域很多时可改成跟上面一样每 40 tick 跑一次
function cardstatus:zone_guard

# ── 场景 3：持紫卡 → 无限夜视（收回卡后自动清除）──
# ⚠ 函数以服务器身份执行，effect give 的提示不会进玩家聊天栏 —— 每 tick 直接给即可
#   （不要写 execute if effect：MC 没有这个子命令，会整个函数加载失败）
# ⚠ 清理行会连玩家自己喝的夜视一起清掉；不需要这个场景就删掉这两行
effect give @a[tag=cobblemarket_purple_card] minecraft:night_vision 999999 0 true
effect clear @a[tag=!cobblemarket_purple_card] minecraft:night_vision
