# 场景 1：没有紫卡 / 黑卡的玩家掉 1 点魔法伤害；持卡玩家免疫
#
# tag=!a 表示「没有这个 tag」。持卡玩家的 tag 由模组在登录 / 发卡 / 收卡时自动维护，
# 服主不需要自己写同步逻辑。
#
# 想只对某个维度生效（示例：下界）：
#   execute in minecraft:the_nether as @a[...] at @s run damage @s 1 minecraft:magic
# 想按计分板判（与 tag 等价）：
#   execute as @a unless score @s cm_purple matches 1 unless score @s cm_black matches 1 run ...
execute as @a[tag=!cobblemarket_purple_card, tag=!cobblemarket_black_card, gamemode=!creative, gamemode=!spectator] at @s run damage @s 1 minecraft:magic
