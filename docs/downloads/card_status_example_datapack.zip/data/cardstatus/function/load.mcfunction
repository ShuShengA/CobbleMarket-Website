# 数据包加载 / /reload 时执行一次：创建示例用的计时器 objective
# ⚠ objective 已存在时这条会失败（控制台一行红字，无害）—— 标准做法，别改成 execute unless score
#   （objective 不存在时 if score 条件本身求值失败，整条 execute 都不会执行 run，建不出来）
scoreboard objectives add carddemo dummy
