# CobbleMarket 持卡状态示例数据包（1.21.1，pack_format 48）

演示怎么用「玩家是否持有喵·紫电卡 / 喵·金轮卡」做服主自己的玩法。
**模组本身不内置任何玩法逻辑**，只提供状态；下面的判定 / 扣血 / 传送都由数据包完成。

## 安装

1. 把本文件夹压成 zip（或直接用现成的 `card_status_example_datapack.zip`）
2. 放进存档的 `datapacks/` 目录
3. `/reload` 或重启服务器

## 模组提供的两条通道

| 通道 | 名字 | 用法示例 |
|---|---|---|
| **实体 tag** | `cobblemarket_purple_card` / `cobblemarket_black_card` | `@a[tag=cobblemarket_purple_card]`、`execute if entity @s[tag=cobblemarket_black_card]` |
| **计分板** | `cm_purple` / `cm_black` = `1` / `0` | `execute if score @s cm_purple matches 1` |

- 由模组在**登录 / 自行申请成功 / 管理员发卡 / 收回卡 / 黑卡升级**时自动维护，服主不用写同步
- 语义 = **持卡名单**（不是"背包里有卡物品"）
- 拿到金轮卡时紫卡资格会被移除 ⇒ 两个值**不会同时为 1**
- 只对**在线玩家**有意义：tag 跟着实体走（下线即消失，上线补）；计分板的值下线保留、上线时重刷

## 三个示例场景

### 1. 持卡免疫持续扣血 —— `data/cardstatus/function/hurt.mcfunction`

每 40 tick（约 2 秒）给**没有卡**的玩家 1 点魔法伤害；持卡玩家完全免疫。

```mcfunction
execute as @a[tag=!cobblemarket_purple_card, tag=!cobblemarket_black_card, gamemode=!creative, gamemode=!spectator] at @s run damage @s 1 minecraft:magic
```

只想在某个维度生效：改成
`execute in minecraft:the_nether as @a[...] at @s run damage @s 1 minecraft:magic`

### 2. 无卡不能进入区域 —— `data/cardstatus/function/zone_guard.mcfunction`

进入示例区域（x 100~110、y 60~80、z 100~110）的**没有卡**的玩家会被传回 (0, 64, 0)。

```mcfunction
execute as @a[x=100,y=60,z=100,dx=11,dy=21,dz=11, tag=!cobblemarket_purple_card, tag=!cobblemarket_black_card] run tp @s 0 64 0
```

- `x,y,z` 是起点、`dx,dy,dz` 是**尺寸**（不是终点坐标）
- 处理方式可换成扣血 / 给负面效果 / 发提示等任意命令

### 3. 持紫卡无限夜视 —— `data/cardstatus/function/tick.mcfunction`（场景 3 两行）

持紫卡自动获得无限夜视（`999999` 秒 ≈ 11.5 天，每 tick 续），收回卡片后下一 tick 自动清除。

```mcfunction
effect give @a[tag=cobblemarket_purple_card] minecraft:night_vision 999999 0 true
effect clear @a[tag=!cobblemarket_purple_card] minecraft:night_vision
```

- 函数以**服务器身份**执行，`effect give` 的提示**不会进玩家聊天栏**，所以可以直接每 tick 给
- ⚠ **不要写 `execute if|unless effect`** —— MC 没有这个子命令，写了整个函数会加载失败
  （日志：`Failed to load function` + `Couldn't load tag minecraft:tick`）
- ⚠ 清理行会连玩家自己喝的夜视一起清掉；不需要这个场景就把这两行删掉

## 安全提醒

tag 与计分板都是**服务端数据**，改客户端无效；但原版命令可以改它们：
`/tag @s add cobblemarket_purple_card`、`/scoreboard players set @s cm_purple 1` 需要 **OP / 命令方块**。

- **别把 OP 给玩家**，否则这些判定会被绕过
- **别在玩家可触发的数据包函数里加这个 tag**（例如做成成就奖励）—— 等于自己开后门
- `cm_purple` / `cm_black` 是模组保留的 objective 名，别自建同名（会被覆盖写入 0/1）
- 这些伪造**不影响模组本身**的权益（商店折扣 / 申请禁令 / 额度都读存档名单，不读 tag）

## 计时器说明

`hurt` 靠计分板 `carddemo` 的假玩家 `#carddemo_tick` 每 40 tick 触发一次；
`tick.mcfunction` 第一句会自动创建这个 objective（重复执行是有保护的）。
如果服主已有同名 objective，把它改名即可。
